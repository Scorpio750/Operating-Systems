#include <stdio.h>
#include "analyzecache.h"

int main(int argc, char *argv[])
{
	return 0;
}
