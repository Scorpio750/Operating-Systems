#ifndef H_MYPTHREAD
#define H_MYPTHREAD

#define STACKSIZE 8192
#define THREADCEILING 1024

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ucontext.h>

static ucontext_t main_program;
static int main_set_up;

// Types
typedef struct {
	// Define any fields you might need inside here.
	int* id;				//thread id
	int* state;			//0 if dead, 1 if running, 2 if blocked
	void* (*start_routine)(void*);	//the function we begin the thread at
	void* args;			//the arguments to pass the function we move to
	ucontext_t* this_context;	//the context belonging to this thread
} mypthread_t;

typedef struct {
	// Define any fields you might need inside here.
	//int stack_size;		//size of the stack, obviously
	//char* stack;			//the stack frame of the thread
} mypthread_attr_t;

// Functions
int mypthread_create(mypthread_t *thread, const mypthread_attr_t *attr,
			void *(*start_routine) (void *), void *arg);

void mypthread_exit(void *retval);

int mypthread_yield(void);

int mypthread_join(mypthread_t thread, void **retval);

int get_id(void);

int get_next_thread(void);

mypthread_t* thread_list[THREADCEILING];
static int current_thread_index;
static int create_thread_index;
static int inThread; //0 for false, 1 for true
static int toRun;
static int total;

/* Don't touch anything after this line.
 *
 * This is included just to make the mtsort.c program compatible
 * with both your ULT implementation as well as the system pthreads
 * implementation. The key idea is that mutexes are essentially
 * useless in a cooperative implementation, but are necessary in
 * a preemptive implementation.
 */

typedef int mypthread_mutex_t;
typedef int mypthread_mutexattr_t;

static inline int mypthread_mutex_init(mypthread_mutex_t *mutex,
			const mypthread_mutexattr_t *attr) { return 0; }

static inline int mypthread_mutex_destroy(mypthread_mutex_t *mutex) { return 0; }

static inline int mypthread_mutex_lock(mypthread_mutex_t *mutex) { return 0; }

static inline int mypthread_mutex_trylock(mypthread_mutex_t *mutex) { return 0; }

static inline int mypthread_mutex_unlock(mypthread_mutex_t *mutex) { return 0; }

#endif
